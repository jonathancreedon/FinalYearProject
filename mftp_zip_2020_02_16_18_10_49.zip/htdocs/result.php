<!DOCTYPE html>
<html>
<head>
	
<title>Jonathan Creedon Final Year Project</title>


</head>
<body>
	 	
	
<nav>
	<ul>
		<li><a href = "homepage.html">Home</a></li>
		<li><a href = "coursesearch.php">Search by Course </a></li>
		<li><a href = "careersearch.html">Search by Department</a></li>
		<li><a href = "Evaluation.html">Evaluate this Website</a></li>		
	</ul>
</nav>	
<main>
<header>
<h1>Course Results</h1>
</header>


<?php

$y = $_GET['course'];
echo $y;


$servername = "sql213.epizy.com";
$username = "epiz_24809542";
$password = "eYSRn38AyDF";
$dbname = "epiz_24809542_CoursesAndCareers";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


function getCareer($c,$conn) {
echo $c;
$sql2 = "SELECT careerCode, CName, CDesc, SalLow, SalHigh FROM Career WHERE (careerCode = '$c') ";
$result2 = $conn->query($sql2);


if ($result2->num_rows > 0) {
    echo "<table><tr><th>Career ID Code</th><th>Career Title</th><th>Possible Jobs</th><th>Lowest Salary</th><th>Highest Salary</th></tr>";
    // output data of each row
    while($row = $result2->fetch_assoc()) {
        echo "<tr><td>".$row["careerCode"]."</td><td>".$row["CName"]."</td><td>".$row["CDesc"]."</td><td> ".$row["SalLow"]."</td><td> ".$row["SalHigh"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
}


$sql = "SELECT courseCode, Title, gradSatisfaction, gradUsefulness FROM Course WHERE (Title='$y')";
$result = $conn->query($sql);


$sql4 = "SELECT probability FROM Evaluation WHERE careerCode = CR002";
$result4 = $conn->query($sql4);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Course ID Code</th><th>Course Title</th><th>Percent Satisfied</th><th>Percent Found Useful</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $link = $row["courseCode"];
        echo "<tr><td>".$row["courseCode"]."</td><td>".$row["Title"]."</td><td>".$row["gradSatisfaction"]."</td><td> ".$row["gradUsefulness"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
//$link = 0;
echo $link;

$sql3 = "SELECT courseCode,careerCode,probability FROM Evaluation WHERE (courseCode = '$link')";
$result3 = $conn->query($sql3);

if ($result3->num_rows > 0) {
   // echo "<table><tr><th>Course ID Code</th><th>Career ID Code</th><th>Percentage Employed</th></tr>";
    // output data of each row
    while($row = $result3->fetch_assoc()) {
        getCareer($row["careerCode"],$conn);
        
       // echo "<tr><td>".$row["courseCode"]."</td><td>".$row["careerCode"]."</td><td>".$row["probability"]."</td></tr>";
    }
   // echo "</table>";
} else {
    echo "0 results";
}


$conn->close();
?>








<footer class = "main">
	
<div><a href = "">&lt;&lt; Older Posts</a></div>	
<div><a href = ""> Newer Posts &gt;&gt;</a></div>	
	
</footer>

</main>
</body>
</html>


<style>
@font-face {
font-family: 'aaarghnormal';
    
src: url('aaargh-webfont.woff2') format('woff2'),

url('aaargh-aaarghwebfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'advent';
    
src: 
url('adventpro-semibold-webfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'mono';
    
src: 
url('MonospaceTypewriter-webfont.woff') format('woff');



}

main{text-align:center;padding-left:25vw;padding-right:25vw;margin-left:0px;margin-right:0px;}



header{font-family:aaarghnormal;font-size:70px;text-align:center;color:red}
nav{font-family:advent;background-color:white;position:fixed;top:0px;left:0px;right:0px;box-shadow:0px 1px 8px;overflow:auto;z-index:2}
nav a{text-decoration:none;padding:0.3em}
a{transition: all 2s;}
a:hover{background-color:rgba(255,0,0,0.5);}



h2{color:red;overflow:auto;font-family:"aaarghnormal";}
h2::first-letter{color:white;background:red;}




footer{font-family:aaarghnormal;float:left;clear:right;font-weight:bold}


footer{font-family:mono;width:100%;}




</style>