<!DOCTYPE html>
<html>
<head>
	
<title>Jonathan Creedon Assignment</title>


</head>
<body>
	 
	

	
	

<main>

	
</div>

<?php
$servername = "sql213.epizy.com";
$username = "epiz_24809542";
$password = "eYSRn38AyDF";
$dbname = "epiz_24809542_CoursesAndCareers";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT courseCode, Title, gradSatisfaction, gradUsefulness FROM Course";
$result = $conn->query($sql);
$sql2 = "SELECT careerCode, CName, CDesc, SalLow, SalHigh FROM Career  ";
$result2 = $conn->query($sql2);
$sql3 = "SELECT probability FROM Evaluation WHERE careerCode = CR001";
$result3 = $conn->query($sql3);
$sql4 = "SELECT probability FROM Evaluation WHERE careerCode = CR002";
$result4 = $conn->query($sql4);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Course ID Code</th><th>Course Title</th><th>Percent Satisfied</th><th>Percent Found Useful</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["courseCode"]."</td><td>".$row["Title"]."</td><td>".$row["gradSatisfaction"]."</td><td> ".$row["gradUsefulness"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

if ($result2->num_rows > 0) {
    echo "<table><tr><th>Career ID Code</th><th>Career Title</th><th>Possible Jobs</th><th>Lowest Salary</th><th>Highest Salary</th></tr>";
    // output data of each row
    while($row = $result2->fetch_assoc()) {
        echo "<tr><td>".$row["careerCode"]."</td><td>".$row["CName"]."</td><td>".$row["CDesc"]."</td><td> ".$row["SalLow"]."</td><td> ".$row["SalHigh"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>





<footer class = "main">
	
<div><a href = "">&lt;&lt; Older Posts</a></div>	
<div><a href = ""> Newer Posts &gt;&gt;</a></div>	
	
</footer>

</main>
</body>
</html>


<style>
@font-face {
font-family: 'aaarghnormal';
    
src: url('aaargh-webfont.woff2') format('woff2'),

url('aaargh-aaarghwebfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'advent';
    
src: 
url('adventpro-semibold-webfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'mono';
    
src: 
url('MonospaceTypewriter-webfont.woff') format('woff');



}

main{text-align:center;padding-left:25vw;padding-right:25vw;margin-left:0px;margin-right:0px;}
div{border-bottom:1px solid black;border-top:1px solid black;text-align:left;}

div#banner{font-family:mono;color:white;width:10em;height:3em;position:absolute;background:red;padding-left:5%;padding-right:5%;border-top:none;border-bottom:none
padding-bottom:2%;padding-top:2%;text-align:center;line-height:30px;right:-5.0em;top:3.5em;transform:rotate(45deg)}

header{font-family:aaarghnormal;font-size:70px;text-align:center;color:red}
nav{font-family:advent;background-color:white;position:fixed;top:0px;left:0px;right:0px;box-shadow:0px 1px 8px;overflow:auto;z-index:2}
ul{list-style-type:none;}
nav ul{list-style-type:none;}
nav li{float:left;padding-left:110px;padding-right:110px;padding-bottom:10px;}
nav a{text-decoration:none;padding:0.3em}
a{transition: all 2s;}
a:hover{background-color:rgba(255,0,0,0.5);}
article{margin-bottom:5em}
article:nth-child(odd){float:left;}
article:nth-child(even){float:right}

ul.date{font-family:mono;background-color:black;color:white;padding:0px;position:absolute;right:20vw;border-radius:50%;height:60px;width:60px;transform:rotate(10deg)}

li.day{font-size:1.2em}
li.month{font-size:0.8em}
li.year{font-size:0.4em}

h2{color:red;overflow:auto;font-family:"aaarghnormal";}
h2::first-letter{color:white;background:red;}

div.picture{border-radius:10%;border:2px solid grey;float:left;margin-top:10px;margin-bottom:10px;margin-right:10px;position:relative;color:#fff;overflow:hidden;font-family:advent}
div.picture img{display:block}
div.picture:hover .caption{height:100%;opacity:1;background:rgba(255,0,0,0.3);}



article>p{font-family:advent;margin-top:5px;margin-left:0;margin-right:0;margin-bottom:0;padding:0px;text-align:justify}
ul.social img{float:right;opacity:0.3;margin:3px;clear:left;transition: opacity 2s}
ul.social img:hover{opacity:1}
body{overflow-x:hidden}
footer{font-family:aaarghnormal;float:left;clear:right;font-weight:bold}
span.taglabel{color:red}

.caption{line-height:300px;position:absolute;width:100%;height:0;overflow:hidden;opacity:0;text-align:center;bottom:0;left:0;right:0;border-top:none;border-bottom:none;background:rgba(255,0,0,1);transition:2s ease}
.caption text{left:50%;top:50%}

footer.main{font-family:mono;width:100%;}
footer.main div:nth-child(1){float:left;border-top:none;border-bottom:none;margin-top:1%;}
footer.main div:nth-child(2){float:right;margin-top:1%;border-top:none;border-bottom:none;}

ol{font-family:advent;}




</style>
