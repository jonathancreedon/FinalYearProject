<?php
echo "
<nav class='navbar navbar-expand-sm bg-dark navbar-dark'>
 <div class='container-fluid'>
	<ul class='navbar-nav' >
		<li class='nav-item'><a class='nav-link' href = 'homepage.php'>Home</a></li>
		<li class='nav-item'><a class='nav-link' href = 'coursesearch.php'>Search by Course </a></li>
		<li class='nav-item'><a class='nav-link' href = 'careersearch.php'>Search by Career</a></li>
		<li class='nav-item'><a class='nav-link' href = 'Evaluation.php'>Evaluate this Website</a></li>
        <li class='nav-item'><a class='nav-link' href = 'courserecommender.php'>Course Recommendation Service</a></li>
        <li class='nav-item'><a class='nav-link' href = 'update.php'>Add to Database</a></li>		
	</ul>
    
  </div>
</nav>	
";
?>