<!DOCTYPE html>
<html>
<head>
	
<title>Jonathan Creedon Final Year Project</title>


</head>
<body>
	 	
	
<nav>
	<ul>
		<li><a href = "homepage.html">Home</a></li>
		<li><a href = "coursesearch.php">Search by Course </a></li>
		<li><a href = "careersearch.html">Search by Department</a></li>
		<li><a href = "Evaluation.html">Evaluate this Website</a></li>		
	</ul>
</nav>	
<main>
<header>
<h1>Search By Course</h1>
</header>


<?php

/*$a = include ('./Controller/populatecourse.php');
echo $a;*/

$servername = "sql213.epizy.com";
$username = "epiz_24809542";
$password = "eYSRn38AyDF";
$dbname = "epiz_24809542_CoursesAndCareers";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT Title FROM Course";
$result = $conn->query($sql);



echo "<select name='courses'>"; 
 
 
foreach($result as $course){ 
  echo "<option value='" . $course['Title'] . "'>" . $course['Title'] . "</option>";
} 
echo"</select>";

$conn->close();

/*<script type="text/javascript">
var c;

$('#courses').on('change', function(){
    c = $(this).val();
});
</script>*/

$t = 10;

echo "<a href=result.php?product_id=c>View Course Data</a>";

?>

<button onclick="window.location.href = 'result.php?';">View Course Data</button>






<footer class = "main">
	
<div><a href = "">&lt;&lt; Older Posts</a></div>	
<div><a href = ""> Newer Posts &gt;&gt;</a></div>	
	
</footer>

</main>
</body>
</html>


<style>
@font-face {
font-family: 'aaarghnormal';
    
src: url('aaargh-webfont.woff2') format('woff2'),

url('aaargh-aaarghwebfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'advent';
    
src: 
url('adventpro-semibold-webfont.woff') format('woff');

font-weight: normal;
    
font-style: normal;

}

@font-face {
font-family: 'mono';
    
src: 
url('MonospaceTypewriter-webfont.woff') format('woff');



}

main{text-align:center;padding-left:25vw;padding-right:25vw;margin-left:0px;margin-right:0px;}



header{font-family:aaarghnormal;font-size:70px;text-align:center;color:red}
nav{font-family:advent;background-color:white;position:fixed;top:0px;left:0px;right:0px;box-shadow:0px 1px 8px;overflow:auto;z-index:2}
nav a{text-decoration:none;padding:0.3em}
a{transition: all 2s;}
a:hover{background-color:rgba(255,0,0,0.5);}



h2{color:red;overflow:auto;font-family:"aaarghnormal";}
h2::first-letter{color:white;background:red;}




footer{font-family:aaarghnormal;float:left;clear:right;font-weight:bold}


footer{font-family:mono;width:100%;}




</style>
