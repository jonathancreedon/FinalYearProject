<?php
class populatecourse{
public function populatecourse(){
include 'connect.php';

$sql = "SELECT Title FROM Course";
$result = $conn->query($sql);

echo '<select name="courses">'; 
 
 
foreach($result as $course){ 
  echo '<option value="' . $course . '">' . $course . '</option>';
} 
echo'</select>';
$conn->close();}

    

?>